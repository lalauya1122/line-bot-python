# -*- coding: utf-8 -*-
from linepy import *
from datetime import datetime
from humanfriendly import format_timespan, format_size, format_number, format_length
import time, random, sys, json, codecs, threading, glob, re, string, os, requests, subprocess, six, ast, urllib, urllib.parse, timeit, _thread
botStart = time.time()
set = {
    "bot1" : [],
    "bots1" : []
}
tkn = json.load(codecs.open("tokens.json","r","utf-8"))
botnum = tkn["botnum"]
if botnum > len(tkn["tokens"]):
    print("所供應的token不足")
    sys.exit()
if type(tkn["tokens"][0]) == str:
    cl = LINE(tkn["tokens"][0]) 
elif type(tkn["tokens"][0]) == list:
    cl = LINE(tkn["tokens"][0][0],tkn["tokens"][0][1]) 
print('主機登入成功 ' + cl.profile.displayName)
b=0
for a in range(botnum-2):
    if type(tkn["tokens"][b+1]) == str:
        set["bot1"].append(LINE(tkn["tokens"][b+1]))
    elif type(tkn["tokens"][b+1]) == list:
        set["bot1"].append(LINE(tkn["tokens"][b+1][0],tkn["tokens"][b+1][1])) 
    b+=1
    print('ok')
if type(tkn["tokens"][botnum-1]) == str:
    js = LINE(tkn["tokens"][botnum-1]) 
elif type(tkn["tokens"][botnum-1]) == list:
    js = LINE(tkn["tokens"][botnum-1][0],tkn["tokens"][botnum-1][1]) 
print('JSprotecter login success\n登入所花時間為'+str(format_timespan(time.time() - botStart)))
Add = []
if tkn["kicker"] != []:
    for token in tkn["kicker"]:
        try:
            Add.append( LINE(token) )
        except:
            tkn["kicker"].remove(token)

clMID = cl.profile.mid
set["bots1"].append(clMID) 
c = 0
for a in range(botnum - 2):
    set["bots1"].append(set["bot1"][c].profile.mid) 
    c+=1
jsMID = js.profile.mid

Kickermid = []
if Add != []:
    for x in Add:
        Kickermid.append(x.profile.mid)

list = []
for x in set["bot1"]:
    list.append(x.profile.mid)

Botmid = {}
Botmid[clMID] = cl
for x in set["bot1"]:
    Botmid[x.profile.mid]=x

Kicker = {}
Kicker[clMID] = set["bot1"]
Kicker[jsMID] = set["bot1"]
for x in set["bot1"]:
    Kicker[x.profile.mid] = set["bot1"][set["bot1"].index(x)+1:]+set["bot1"][:set["bot1"].index(x)]

oepoll = OEPoll(cl)

ban = json.load(codecs.open("ban.json","r","utf-8"))
gp = json.load(codecs.open("group.json","r","utf-8"))
settings = json.load(codecs.open("temp.json","r","utf-8"))
pt = json.load(codecs.open("protect.json","r","utf-8"))
#==============================================================================#
def restartBot():
    print ("[ INFO ] BOT RESETTED")
    backupData()
    python = sys.executable
    os.execl(python, python, *sys.argv)
def backupData():
    try: 
        json.dump(ban, codecs.open('ban.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False) 
        json.dump(gp, codecs.open('group.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False)
        json.dump(settings,codecs.open('temp.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False)
        json.dump(pt,codecs.open('protect.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False)
        json.dump(tkn,codecs.open('tokens.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False
def ismid(mid):
    try:
        cl.getContact(mid)
        return True
    except:
        return False
def cek(mid):
    if mid  in (ban["admin"] + ban["owners"] + set["bots1"] + Kickermid):
        return True
    else:
        return False
def killban(to):
    group = cl.getGroup(to)
    gMembMids = [contact.mid for contact in group.members]
    matched_list = []
    for tag in ban["blacklist"]:
        matched_list+=filter(lambda str: str == tag, gMembMids)
    if matched_list == []:
        return True
    else:
        for jj in matched_list:
            random.choice(set["bot1"]).kickoutFromGroup(to,[jj])
        cl.sendMessage(to, "黑名單以踢除")
        return False
def joinLink(x,to,on=False):
    G = cl.getGroup(to)
    if G.preventedJoinByTicket != on:
        G.preventedJoinByTicket = on
        x.updateGroup(G)
def logError(text):
    cl.log("[ ERROR ] " + str(text))
    time_ = datetime.now()
    with open("errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))
def helpmessage():
    helpMessage = """╔═══════
╠♥ ✿✿ すずかの Bot ✿✿ ♥
╠══✪〘 For Admin 〙✪═══
╠➥ Botset-查看機器設定
╠➥ Gc-查詢自己剩餘票數
╠➥ Test-機器報數
╠➥ 喵-蘿莉共鳴
╠➥ Speed-速度
╠➥ Join-分身入防
╠➥ bye-分身解防
╠➥ @bye-解防(含主機)
╠➥ Save-儲存設定
╠➥ Gadd @-新增群管
╠➥ Gdel @-刪除群管
╠➥ Mid-友資查mid
╠➥ GM-查看本群管理者
╠➥ Banlist-黑單
╠➥ Adminlist-權限者清單
╚〘Created By ©ながみ すずか™ 〙"""
    return helpMessage
def helpmessagetag():
    helpMessageTag ="""╔═══════
╠♥ ✿✿ すずかの Bot ✿✿ ♥
╠══✪〘 For Owner 〙✪═══
╠➥ Bothelp-機器設定指令
╠➥ Botset-查看機器設定
╠➥ Lg-所有群組列表
╠➥ Mid-友資查mid
╠➥ Gadd @-新增群管
╠➥ Gdel @-刪除群管
╠➥ GM-查看本群管理者
╠➥ Rebot-重新啟動
╠➥ Tk @-多標踢人
╠➥ Gc mid-MID查票
╠➥ Add @-新增權限
╠➥ Add-友資新增權限
╠➥ Del @-刪除權限
╠➥ Del-友資刪除權限
╠➥ A mid (times)-加票
╠➥ Ban:mid-MID黑單
╠➥ Ban-友資黑單
╠➥ Ban @-標注黑單
╠➥ Unban:mid-MID黑單
╠➥ Unban-友資黑單
╠➥ Unban @-標注黑單
╠➥ Gc-查詢自己剩餘票數
╠➥ Test-機器報數
╠➥ 喵-蘿莉共鳴
╠➥ Speed-速度
╠➥ Join-分身入防
╠➥ bye-分身解防
╠➥ @bye-解防(含主機)
╠➥ Save-儲存設定
╠➥ Banlist-黑單
╠➥ Adminlist-權限者清單
╠➥ Clear ban-清除黑單
╠➥ Kg-全群掃黑
╠➥ Kill ban-當前群組掃黑
╚〘Created By ©ながみ すずか™ 〙"""
    return helpMessageTag
def helpn():
    helpN = """╔═══════
╠♥ ✿✿ すずかの Bot ✿✿ ♥
╠══✪〘 For All 〙✪═══
╠➥ Gc-查詢自己剩餘票數
╠➥ Test-機器報數
╠➥ 喵-蘿莉共鳴
╠➥ Speed-速度
╠➥ Mid-友資查mid
╠➥ GM-查看本群管理者
╚〘Created By ©ながみ すずか™ 〙"""
    return helpN
def helpbot():
    helpBot = """╔═══════
╠ ✺❂✺ すずかの Bot ✺❂✺
╠══✪〘 Setting 〙✪═══
╠✪〘 Bots 〙✪══════
╠➥ Mode ticket-機器網址入群
╠➥ Mode invite-機器網址入群
╠➥ Mode kicker-機器使用追加
╠✪〘 Kicker Set 〙✪════
╠➥ KickerAdd:(token)-登入追加
╠➥ KickerDel:(mid)-追加清除
╠➥ KickerList-查看所有追加
╠➥ Kicker Test-追加測試
╠✪〘 Groups 〙✪═════
╠➥ JS pro/off-JS翻機特別防禦
╠➥ Pro On/Off 所有保護
╠➥ Protect On/Off 踢人保護
╠➥ QrProtect On/Off 網址保護
╠➥ Invprotect On/Off 邀請保護
╚〘Created By ©ながみ すずか™ 〙"""
    return helpBot

wait = {
    "ban" : False,
    "unban" : False,
    "add" : False,
    "del" : False,
    "mid" : False,
    "clp" : False,
    "botp" : False
}

if clMID not in ban["owners"]:
    ban["owners"].append(clMID)

def lineBot(op):
    try:
        if op.type == 0:
            return
        if op.type == 11:
            if cek(op.param2) or (op.param1 in gp["s"] and op.param2 in gp["s"][op.param1]):
                pass
            else:
                G = cl.getGroup(op.param1)
                if G.preventedJoinByTicket == False and op.param1 in pt["qrprotect"]:
                    G.preventedJoinByTicket = True
                    random.choice(set["bot1"]).updateGroup(G)
                    random.choice(set["bot1"]).kickoutFromGroup(op.param1,[op.param2])
                    ban["blacklist"][op.param2] = True
                    json.dump(ban, codecs.open('ban.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False) 
        if op.type == 17:
            if op.param2 in ban["blacklist"]: 
                if settings["warmode"] == None:
                    joinLink(random.choice(set["bot1"]),op.param1)
                    Ticket = random.choice(set["bot1"]).reissueGroupTicket(op.param1)
                    b = random.choice(Add)
                    b.acceptGroupInvitationByTicket(op.param1,Ticket)
                    b.kickoutFromGroup(op.param1,[op.param2])
                    joinLink(b,op.param1,True)
                    b.leaveGroup(op.param1)
                else:
                    random.choice(set["bot1"]).kickoutFromGroup(op.param1,[op.param2])
                    joinLink(random.choice(set["bot1"]),op.param1,True)
        if op.type ==19:
            if cek(op.param2) or (op.param1 in gp["s"] and op.param2 in gp["s"][op.param1]):
                pass
            elif settings["warmode"] != None and op.param1 in pt["protect"]:
                ban["blacklist"][op.param2] = True
                json.dump(ban, codecs.open('ban.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False) 
                for x in set["bot1"]:
                    try:
                        x.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        continue
                    else:
                        break
            elif op.param3 not in set["bots1"] and op.param1 in pt["protect"] and settings["warmode"] == None:
                ban["blacklist"][op.param2] = True
                json.dump(ban, codecs.open('ban.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False) 
                for x in set["bot1"]:
                    try:
                        joinLink(x,op.param1)
                        Ticket = x.reissueGroupTicket(op.param1)
                        b = random.choice(Add)
                        b.acceptGroupInvitationByTicket(op.param1,Ticket)
                        b.kickoutFromGroup(op.param1,[op.param2])
                        joinLink(b,op.param1,True)
                        b.leaveGroup(op.param1)
                    except:
                        continue
                    else:
                        break
            if op.param3 in ban["owners"] and op.param3 != clMID:
                random.choice(set["bot1"]).findAndAddContactsByMid(op.param3)
                random.choice(set["bot1"]).inviteIntoGroup(op.param1,[op.param3])
        if op.type ==19:
            if op.param3 in set["bots1"] and settings["warmode"] == True:
                for x in Kicker[op.param3]:
                    try:
                        joinLink(x,op.param1)
                        Ticket = x.reissueGroupTicket(op.param1)
                        Botmid[op.param3].acceptGroupInvitationByTicket(op.param1,Ticket)
                    except:
                        continue
                    else:
                        break
                else:
                    if op.param1 in pt["jspro"]:
                        try:
                            js.acceptGroupInvitation(op.param1)
                            js.kickoutFromGroup(op.param1,[op.param2])
                            joinLink(js,op.param1)
                            Ticket = js.reissueGroupTicket(op.param1)
                            cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                            for y in set["bot1"]:
                                y.acceptGroupInvitationByTicket(op.param1,Ticket)
                            js.leaveGroup(op.param1)
                        except:
                            pass
                try:
                    random.choice(set["bot1"]).cancelGroupInvitation(op.param1,[op.param2])
                    cl.reissueGroupTicket(op.param1)
                    joinLink(random.choice(set["bot1"]),op.param1,True)
                except:
                    pass
            elif op.param3 in set["bots1"] and settings["warmode"] == False:
                for x in Kicker[op.param3]:
                    try:
                        x.findAndAddContactsByMid(op.param3)
                        x.inviteIntoGroup(op.param1,[op.param3])
                        Botmid[op.param3].acceptGroupInvitation(op.param1)
                    except:
                        continue
                    else:
                        break
                else:
                    if op.param1 in pt["jspro"]:
                        try:
                            js.acceptGroupInvitation(op.param1)
                            js.kickoutFromGroup(op.param1,[op.param2])
                            joinLink(js,op.param1)
                            Ticket = js.reissueGroupTicket(op.param1)
                            cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                            for y in set["bot1"]:
                                y.acceptGroupInvitationByTicket(op.param1,Ticket)
                            js.leaveGroup(op.param1)
                        except:
                            pass
                try:
                    random.choice(set["bot1"]).cancelGroupInvitation(op.param1,[op.param2])
                    cl.reissueGroupTicket(op.param1)
                    joinLink(x,op.param1,True)
                except:
                    pass
            elif op.param3 in set["bots1"] and settings["warmode"] == None:
                for x in Kicker[op.param3]:
                    try:
                        joinLink(x,op.param1)
                        Ticket = x.reissueGroupTicket(op.param1)
                        Botmid[op.param3].acceptGroupInvitationByTicket(op.param1,Ticket)
                        if cek(op.param2) or (op.param1 in gp["s"] and op.param2 in gp["s"][op.param1]):
                            pass
                        else:
                            b = random.choice(Add)
                            b.acceptGroupInvitationByTicket(op.param1,Ticket)
                            b.kickoutFromGroup(op.param1,[op.param2])
                            joinLink(b,op.param1,True)
                            b.cancelGroupInvitation(op.param1,[op.param2])
                            b.leaveGroup(op.param1)
                            ban["blacklist"][op.param2] = True
                            json.dump(ban, codecs.open('ban.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False) 
                    except:
                        continue
                    else:
                        break
                else:
                    if op.param1 in pt["jspro"]:
                        try:
                            js.acceptGroupInvitation(op.param1)
                            js.kickoutFromGroup(op.param1,[op.param2])
                            joinLink(js,op.param1)
                            Ticket = js.reissueGroupTicket(op.param1)
                            cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                            for y in set["bot1"]:
                                y.acceptGroupInvitationByTicket(op.param1,Ticket)
                            js.leaveGroup(op.param1)
                        except:
                            pass
        if op.type == 13:
            if op.param1 in pt["invprotect"]:
                if cek(op.param2) or (op.param1 in gp["s"] and op.param2 in gp["s"][op.param1]):
                    pass
                else:
                    random.choice(set["bot1"]).kickoutFromGroup(op.param1,[op.param2])
                    try:
                        random.choice(set["bot1"]).cancelGroupInvitation(op.param1,[op.param3])
                    except:
                        random.choice(set["bot1"]).kickoutFromGroup(op.param1,[op.param3])
                    ban["blacklist"][op.param2] = True
                    json.dump(ban, codecs.open('ban.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False) 
        if op.type == 32:
            if op.param3 in set["bots1"]:
                if not cek(op.param2):
                    for x in Kicker[op.param3]:
                        try:
                            random.choice(set["bot1"]).kickoutFromGroup(op.param1,[op.param2])
                            ban["blacklist"][op.param2] = True
                            json.dump(ban, codecs.open('ban.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False) 
                        except:
                            pass
                        else:
                            break
            elif op.param3 in [jsMID] + ban["owners"]:
                if op.param2 in ban["admin"] or op.param2 in ban["owners"] or op.param2 in set["bots1"]:
                    for x in set["bot1"]:
                        try:
                            x.findAndAddContactsByMid(op.param3)
                            x.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            pass
                        else:
                            break
                else:
                    for x in Kicker[op.param3]:
                        try:
                            x.kickoutFromGroup(op.param1,[op.param2])
                            x.findAndAddContactsByMid(op.param3)
                            x.inviteIntoGroup(op.param1,[op.param3])
                            ban["blacklist"][op.param2] = True
                            json.dump(ban, codecs.open('ban.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False) 
                        except:
                            pass
                        else:
                            break
        if op.type == 5:
            cl.sendMessage(op.param1, "你好 {} 謝謝你加我為好友 ε٩(๑> ₃ <)۶з \n此機器為防翻機器人 1張票200元整\n有興趣可以私以下友資購買".format(str(cl.getContact(op.param1).displayName)))
            cl.sendContact(op.param1,'u0505fe1fb484fc1537d12ad53a5a4ea2')
            cl.sendContact(op.param1,'ua10c2ad470b4b6e972954e1140ad1891')
        if op.type == 13:
            if clMID in op.param3:
                if op.param2 in set["bots1"]:
                    pass
                elif op.param2 == jsMID:
                    cl.acceptGroupInvitation(op.param1)
                elif op.param2 in ban["owners"]:
                    cl.acceptGroupInvitation(op.param1)
                    cl.sendMessage(op.param1,"謝謝主人的邀請～結月來報到囉(≧▽≦)")
                    G = cl.getGroup(op.param1)
                    if op.param1 not in gp["s"]:
                        gp["s"][op.param1] = []
                    try:
                        if G.creator.mid not in gp["s"][op.param1]:
                            gp["s"][op.param1].append(G.creator.mid)
                    except:
                        if op.param2 not in gp["s"][op.param1]:
                            gp["s"][op.param1].append(op.param2)
                elif op.param2 in ban["user"]:
                    if "gid" in ban["user"][op.param2] :
                        ban["user"][op.param2].remove("gid")
                        ban["user"][op.param2].append(op.param1)
                        text = "你還擁有{}張票".format(str(ban["user"][op.param2].count("gid")))
                    elif op.param1 in ban["user"][op.param2]:
                       text = "票卷擁有者邀請入群\n輸入join機器便會入群防護"
                    else:
                        return
                    cl.acceptGroupInvitation(op.param1)
                    cl.sendMessage(op.param1,text)
                    if op.param1 not in gp["s"]:
                        gp["s"][op.param1] =[]
                    if op.param2 not in gp["s"][op.param1]:
                        gp["s"][op.param1].append(op.param2)
                    G = cl.getGroup(op.param1)
                    try:
                        if G.creator.mid not in gp["s"][op.param1]:
                            gp["s"][op.param1].append(G.creator.mid)
                    except:
                        pass
                    cl.sendMessage(op.param1,"已設置此群群長為邀請者與創群者")
                    backupData()
                else:
                    cl.sendMessage(op.param2,"你的票不夠啦ヾ(;ﾟ;Д;ﾟ;)ﾉﾞ")
        if op.type == 24 or op.type == 21 or op.type ==22:
            Botmid[op.param3].leaveRoom(op.param1)
        if (op.type == 25 or op.type == 26) and op.message.contentType == 0:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != cl.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 0:
                if text is None:
                    return
            if sender in ban["admin"] or sender in ban["owners"] or (to in gp["s"] and sender in gp["s"][to]):
                if text.lower() =='@bye':
                    try:
                        random.choice(set["bot1"]).sendMessage(to,"下次再見囉~")
                        cl.sendMessage(to,'Bye~Bye~')
                        for x in set["bot1"]:
                            x.leaveGroup(msg.to)
                        group = cl.getGroup(msg.to)
                        if group.invitee != None:
                            gMembMids = [contact.mid for contact in group.invitee]
                            if jsMID in gMembMids :
                                cl.cancelGroupInvitation(to,[jsMID])
                    except:
                        pass
                    if to in pt["jspro"]:
                        del pt["jspro"][to]
                    if to in pt["protect"]:
                        del pt["protect"][to]
                    if to in pt["qrprotect"]:
                        del pt["qrprotect"][to]
                    if to in pt["invprotect"]:
                        del pt["invprotect"][to]
                    if sender in ban["user"] and to in ban["user"][sender]:
                        ban["user"][sender].remove(to) 
                        ban["user"][sender].append("gid")   
                    cl.leaveGroup(msg.to)
            if sender in sender:
                if ".kickall" in text.lower() or text.lower() == "kick on" or "kickall" in text.lower():
                    if sender not in ban["owners"]:
                        pro = random.choice(set["bot1"])
                        pro.kickoutFromGroup(to,[sender])
                        cl.sendMessage(to, "{} 嘗試使用翻群指令\n基於安全考量 暫時踢出".format(str(cl.getContact(sender).displayName)))
                elif text.lower() == 'gc':
                    if sender in ban["user"]:
                        cl.sendMessage(to,"你還擁有{}張票".format(str(ban["user"][op.param2].count("gid"))))
                    else:
                        cl.sendMessage(to,"沒有票惹(´°̥̥̥̥̥̥̥̥ω°̥̥̥̥̥̥̥̥｀)歡迎購買邀請票券")
                elif text.lower() == 'mid':
                    wait["mid"]=True
                    cl.sendMessage(to,"please send a contact")
                elif text.lower() == 'join':
                    if sender in ban["owners"] or (sender in ban["user"] and to in ban["user"][sender]):
                        if settings["warmode"] == False :
                            for x in list:
                                cl.findAndAddContactsByMid(x)
                            cl.inviteIntoGroup(to,list)
                            for x in set["bot1"]:
                                x.acceptGroupInvitation(to)
                            pt["protect"][to] = True
                            pt["qrprotect"][to] = True
                            pt["invprotect"][to] = True
                            cl.sendMessage(to, "預設踢人保護開啟")
                            cl.sendMessage(to, "預設網址保護開啟")
                            cl.sendMessage(to, "預設邀請保護開啟")
                            killban(to)
                        else:
                            joinLink(cl,to)
                            Ticket = cl.reissueGroupTicket(msg.to)
                            for y in set["bot1"]:
                                y.acceptGroupInvitationByTicket(msg.to,Ticket)
                            joinLink(cl,to,True)
                            pt["protect"][to] = True
                            pt["qrprotect"][to] = True
                            pt["invprotect"][to] = True
                            cl.sendMessage(to, "預設踢人保護開啟")
                            cl.sendMessage(to, "預設網址保護開啟")
                            cl.sendMessage(to, "預設邀請保護開啟")
                            killban(to)
                elif text.lower() == '確認':
                    G = cl.getGroup(msg.to)
                    group = cl.getGroup(to)
                    contact = cl.getContact(sender)
                    try:
                       for mi_d in gp["a"][G.id]:
                           Gf = cl.getContact(mi_d).displayName
                    except:
                        Gf = "未設定"
                    try:
                       for mi_d in pp["a"][G.id]:
                           gn = cl.getContact(mi_d).displayName
                    except:
                        gn = "未指定"
                    if group.invitee is None:
                        gPending = "0"
                    else:
                        gPending = str(len(group.invitee))
                    if group.preventedJoinByTicket == True:
                        gQr = "關閉"
                        gTicket = "無"
                    else:
                        gQr = "開啟"
                        gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(group.id)))
                    ret_ = "➢ 群組資訊"
                    ret_ += "\n➢ 你好{}".format(cl.getContact(sender).displayName)
                    ret_ += "\n➢ 群組名稱 : {}".format(str(group.name))				
                    ret_ += "\n➢ 群組 Id : {}".format(group.id)
                    ret_ += "\n➢ 群長："
                    ret_ += "\n➢ {}".format(Gf)
                    ret_ += "\n➢ 副群長："
                    ret_ += "\n➢ {}".format(gn)
                    ret_ += "\n➢ 網址狀態 : {}".format(gQr)
                    ret_ += "\n➢ 群組網址 : {}".format(gTicket)
                    ret_ += "\n➢ 群組人數 : {}".format(str(len(group.members)))
                    ret_ += "\n➢ 邀請中 : {}".format(gPending)
                    ret_ += "\n➢[ 機器模式 ]"					
                    if settings["warmode"] ==True: ret_+="\n➢ 機器入群模式 ※網址進入※"
                    elif settings["warmode"] ==False: ret_ += "\n➢ 機器入群模式 ※邀請進入※"
                    else: ret_ += "\n➢ 機器入群模式 ※追加踢人進群※"
                    if msg.toType==2:
                        ret_ += "\n➢[ 單群設定 ]"
                        G = cl.getGroup(msg.to)
                        ret_ += "\n➢ 群組名稱 : {}".format(str(G.name))
                        if G.id in settings["protect"] : ret_+="\n➢ 踢人保護 ✅"
                        else: ret_ += "\n➢ 踢人保護 ❌"
                        if G.id in settings["qrprotect"] : ret_+="\n➢ 網址保護 ✅"
                        else: ret_ += "\n➢ 網址保護 ❌"
                        if G.id in settings["invprotect"] : ret_+="\n➢ 邀請保護 ✅"
                        else: ret_ += "\n➢ 邀請保護 ❌"
                        if G.id in settings["jspro"]: ret_+="\n➢ JS翻機保護 ✅"
                        else: ret_ += "\n➢ JS翻機保護 ❌"						
                    ret_ += "\n↠群管↞"
                    for mi_d in gp["s"][to]:
                        ret_ += "\n➢ " +cl.getContact(mi_d).displayName  
                    cl.sendMessage(to, str(ret_ ))			
                elif text.lower() =='test':
                    a=1
                    cl.sendMessage(to,str(a))
                    try:
                        G = random.choice(set["bot1"]).getGroup(to)
                        for x in set["bot1"]:
                            a+=1
                            x.sendMessage(to,str(a))
                    except:
                        pass
                elif text.lower() == 'speed':
                    start = time.time()
                    cl.sendMessage(to, "計算中...")
                    elapsed_time = time.time() - start
                    cl.sendMessage(to,format(str(elapsed_time)))
                elif text.lower() == 'gm':
                    G = cl.getGroup(to)
                    if G.id not in gp["s"] or gp["s"][G.id]==[]:
                        cl.sendMessage(to,"無群管!")
                    else:
                        mc = "╔══[ Group Manager ]"
                        for mi_d in gp["s"][G.id]:
                            mc += "\n╠ "+cl.getContact(mi_d).displayName
                        cl.sendMessage(to,mc + "\n╚══[ Finish ]")
                elif text.lower() == 'help':
                    if sender in ban["owners"]:
                        helpMessageTag = helpmessagetag()
                        cl.sendMessage(to, str(helpMessageTag))
                    elif sender in ban["admin"]:
                        helpMessage = helpmessage()
                        cl.sendMessage(to, str(helpMessage))
                    else:
                        helpN = helpn()
                        cl.sendMessage(to, str(helpN))
            if sender in ban["admin"] or sender in ban["owners"]:
                if text.lower() == 'botset':
                    try:
                        ret_ = "╔══[ 本機設定 ]"
                        if settings["warmode"] ==True: ret_+="\n╠ 機器入群模式 ※網址※"
                        elif settings["warmode"] ==False: ret_ += "\n╠ 機器入群模式 ※邀請※"
                        else: ret_ += "\n╠ 機器入群模式 ※追加※"
                        if msg.toType==2:
                            ret_ += "\n╠══[ 單群設定 ]"
                            G = cl.getGroup(msg.to)
                            ret_ += "\n╠ 群組名稱 : {}".format(str(G.name))
                            if G.id in pt["protect"] : ret_+="\n╠ 踢人保護 ✅"
                            else: ret_ += "\n╠ 踢人保護 ❌"
                            if G.id in pt["qrprotect"] : ret_+="\n╠ 網址保護 ✅"
                            else: ret_ += "\n╠ 網址保護 ❌"
                            if G.id in pt["invprotect"] : ret_+="\n╠ 邀請保護 ✅"
                            else: ret_ += "\n╠ 邀請保護 ❌"
                            if G.id in pt["jspro"]: ret_+="\n╠ JS翻機保護 ✅"
                            else: ret_ += "\n╠ JS翻機保護 ❌"
                        ret_ += "\n╠ 版本號 <喵防2.0>\n╚[ By 蘿莉喵 ]"
                        cl.sendMessage(to, str(ret_))
                    except Exception as e:
                        cl.sendMessage(msg.to, str(e))
                elif text.lower() == 'save':
                    backupData()
                    cl.sendMessage(to,'儲存設定成功!')
                elif text.lower() == 'runtime':
                    cl.sendMessage(to, "系統已運作 {}".format(str(format_timespan(time.time() - botStart))))
                elif text.lower() =='bye':
                    try:
                        random.choice(set["bot1"]).getGroup(to)
                        cl.sendMessage(to,'Bye~Bye~QQ')
                        for x in set["bot1"]:
                            x.leaveGroup(msg.to)
                        group = cl.getGroup(msg.to)
                        if group.invitee != None:
                            gMembMids = [contact.mid for contact in group.invitee]
                            if jsMID in gMembMids :
                                cl.cancelGroupInvitation(to,[jsMID])
                    except:
                        pass
                    if to in pt["jspro"]:
                        del pt["jspro"][to]
                    if to in pt["protect"]:
                        del pt["protect"][to]
                    if to in pt["qrprotect"]:
                        del pt["qrprotect"][to]
                    if to in pt["invprotect"]:
                        del pt["invprotect"][to]
                elif text.lower() == 'adminlist':
                    if ban["admin"] == []:
                        cl.sendMessage(to,"無擁有權限者!")
                    else:
                        mc = "╔══[ Admin List ]"
                        for mi_d in ban["admin"]:
                            try:
                                mc += "\n╠ "+cl.getContact(mi_d).displayName
                            except:
                                pass
                        cl.sendMessage(to,mc + "\n╚══[ Finish ]")
                elif text.lower() == 'banlist':
                    if ban["blacklist"] == {}:
                        cl.sendMessage(msg.to,"無黑單成員!")
                    else:
                        mc = "[ Black List ]"
                        for mi_d in ban["blacklist"]:
                            try:
                                mc += "\n↬ "+cl.getContact(mi_d).displayName+"\n"+str(mi_d)
                            except:
                                ban["blacklist"].remove(mi_d)
                                print("error")
                        cl.sendMessage(msg.to,mc + "\n[ Finish ]")
                elif text.lower().startswith("gadd "):
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    G = cl.getGroup(to)
                    if G.id not in gp["s"]:
                        gp["s"][G.id] =[]
                        for x in key["MENTIONEES"]:
                            gp["s"][G.id].append(x["M"])
                        cl.sendMessage(to, "已獲得權限！")
                    else:
                        for x in key["MENTIONEES"]:
                            gp["s"][G.id].append(x["M"])
                        cl.sendMessage(to,"OK")
                elif text.lower().startswith("gdel "):
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    G = cl.getGroup(to)
                    if G.id not in gp["s"]:
                        cl.sendMessage(to, "There is no group manager！")
                    else:
                        for x in key["MENTIONEES"]:
                            try:
                                gp["s"][G.id].remove(x["M"])
                            except:
                                cl.sendMessage(to,"Not in GM.")
                        cl.sendMessage(to,"OK")
            if sender in ban["owners"]:
                if text.lower() == 'lg':
                        groups = cl.groups
                        ret_ = "[群組列表]"
                        no = 1
                        for gid in groups:
                            group = cl.getGroup(gid)
                            ret_ += "\n {}. {} | {}".format(str(no), str(group.name), str(len(group.members)))
                            no += 1
                        ret_ += "\n[總共 {} 個群組]".format(str(len(groups)))
                        cl.sendMessage(to, str(ret_))
                elif text.lower() == 'bothelp':
                    helpBot = helpbot()
                    cl.sendMessage(to, str(helpBot))
                elif text.lower() == 'mode ticket':
                    settings["warmode"] = True
                    cl.sendMessage(to, "bot will join by ticket")
                elif text.lower() == 'mode invite':
                    settings["warmode"] = False
                    cl.sendMessage(to,"bot will invit each other")
                elif text.lower() == 'mode kicker':
                    settings["warmode"] = None
                    cl.sendMessage(to,"other bot will help kick")
                    if Add == []:
                        cl.sendMessage(to,"There is no kicker.Use KickerAdd:Token for adding")
                elif text.lower() == 'qrprotect on':
                    if msg.toType ==2:
                        try:
                            random.choice(set["bot1"]).sendMessage(to,"網址保護開啟")
                            pt["qrprotect"][to] = True
                        except:
                            cl.sendMessage(to, "bots is not here.")
                elif text.lower() == 'qrprotect off':
                    if msg.toType ==2 :
                        try:
                            del pt["qrprotect"][to]
                            cl.sendMessage(to, "網址保護關閉")
                        except:
                            cl.sendMessage(to, "沒開你是要關洨==")
                elif text.lower() == 'invprotect on':
                    if msg.toType ==2:
                        try:
                            random.choice(set["bot1"]).sendMessage(to,"邀請保護開啟")
                            pt["invprotect"][to] = True
                        except:
                            cl.sendMessage(to, "bots is not here.")
                elif text.lower() == 'invprotect off':
                    if msg.toType ==2 :
                        try:
                            del pt["invprotect"][to]
                            cl.sendMessage(to, "邀請保護關閉")
                        except:
                            cl.sendMessage(to, "沒開你是要關洨==")
                elif text.lower() == 'protect on':
                    if msg.toType ==2:
                        try:
                            random.choice(set["bot1"]).sendMessage(to,"踢人保護開啟")
                            pt["protect"][to] = True
                        except:
                            cl.sendMessage(to, "機器沒有在群組")
                elif text.lower() == 'protect off':
                    if msg.toType ==2 :
                        try:
                            del pt["protect"][to]
                            cl.sendMessage(to, "踢人保護關閉")
                        except:
                            cl.sendMessage(to, "沒開你是要關洨==")
                elif text.lower() == 'pro on':
                    if msg.toType ==2:
                        try:
                            random.choice(set["bot1"]).sendMessage(to, "幫您開啟保護功能\n踢人保護開啟\n網址保護開啟\n邀請保護開啟")
                            pt["protect"][to] = True
                            pt["qrprotect"][to] = True
                            pt["invprotect"][to] = True
                        except:
                            cl.sendMessage(to, "機器沒有在群組")
                elif text.lower() == 'pro off':
                    if msg.toType ==2:
                        G = cl.getGroup(msg.to)
                        try:
                            del pt["protect"][G.id]
                        except:
                            pass
                        try:
                            del pt["qrprotect"][G.id]
                        except:
                            pass
                        try:
                            del pt["invprotect"][G.id]
                            cl.sendMessage(to, "幫您關閉保護功能\n踢人保護關閉\n網址保護關閉\n邀請保護關閉")
                        except:
                            pass
                elif text.lower() == 'js pro':
                    if msg.toType ==2 and to not in pt["jspro"]:
                        cl.sendMessage(to,"取消保護開啟")
                        cl.findAndAddContactsByMid(jsMID)
                        cl.inviteIntoGroup(to,[jsMID])
                        pt["jspro"][to] = True
                        json.dump(pt,codecs.open('protect.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False)
                elif text.lower() == 'js off':
                    if msg.toType ==2 and to in settings["jspro"]:
                        cl.sendMessage(to,"取消保護關閉")
                        del pt["jspro"][to]
                        group = cl.getGroup(to)
                        if group.invitee != None:
                            gMembMids = [contact.mid for contact in group.invitee]
                            if jsMID in gMembMids :
                                cl.cancelGroupInvitation(to,[jsMID])
                elif text.lower().startswith("kickeradd:"):
                    token = text.split(':',2)[1]
                    try:
                        Add.append( LINE(token) )
                        tkn["kicker"].append(str(token))
                        Kickermid.append(Add[-1].profile.mid)
                        cl.sendMessage(to,"success login to line")
                        json.dump(tkn,codecs.open('tokens.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False)
                    except:
                        cl.sendMessage(to,"error")
                elif text.lower().startswith("kickerdel:"):
                    mi_d = text.split(':',2)[1]
                    for x in Add:
                        if x.profile.mid == mi_d:
                            Add.remove(x)
                            tkn["kicker"].remove(str(x.authToken))
                    cl.sendMessage(to,"OK")
                elif text.lower() =='kickerlist':
                    if Add == []:
                        cl.sendMessage(msg.to,"無追加保鏢!\n無保鏢時追加系統無法正常運作\n輸入kickeradd:帳號token以登入追加")
                    else:
                        mc = "[ Kicker List ]"
                        for x in Add:
                            mc += "\n↬ "+x.profile.displayName+"\n"+str(x.profile.mid)
                        cl.sendMessage(msg.to,mc + "\n[ Finish ]")
                elif text.lower() == 'kicker test':
                    joinLink(cl,to)
                    Ticket = cl.reissueGroupTicket(to)
                    for y in Add:
                        y.acceptGroupInvitationByTicket(to,Ticket)
                    joinLink(cl,to,True)
                    for y in Add:
                        y.sendMessage(to,"test")
                    for y in Add:
                        y.leaveGroup(to)
                elif text.lower().startswith("gc "):
                    x = text[3:]
                    if x in ban["user"]:
                        cl.sendMessage(to,"還擁有{}張票".format(str(ban["user"][x].count("gid"))))
                    else:
                        cl.sendMessage(to,"沒有票惹(´°̥̥̥̥̥̥̥̥ω°̥̥̥̥̥̥̥̥｀)歡迎購買邀請票券")
                elif text.lower() == 'rebot':
                    cl.sendMessage(to, "重新啟動中...")
                    cl.sendMessage(to, "重啟成功")
                    restartBot()
                elif text.lower() == 'clear ban':
                    for mi_d in ban["blacklist"]:
                        ban["blacklist"] = {}
                    cl.sendMessage(to, "已清空黑名單")
                    json.dump(ban, codecs.open('ban.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False) 
                elif text.lower().startswith("tk "):
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    targets = []
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    if settings["warmode"] != None:
                        for target in targets:
                            if target in ban["owners"] or target in set["bots1"]:
                                pass
                            try:
                                random.choice(set["bot1"]).kickoutFromGroup(to,[target])
                            except:
                                pass
                    else:
                        joinLink(cl,to)
                        Ticket = cl.reissueGroupTicket(to)
                        y = random.choice(Add)
                        y.acceptGroupInvitationByTicket(to,Ticket)
                        for target in targets:
                            if target in ban["owners"] or target in set["bots1"]:
                                pass
                            else:
                                y.kickoutFromGroup(to,[target])
                        joinLink(y,to,True)
                        y.leaveGroup(to)
                elif text.lower() == 'kg':
                    gid = cl.getGroupIdsJoined() 
                    for i in gid:
                        killban(i)
                elif text.lower() == 'kill ban':
                    if msg.toType == 2:
                        if killban(to):
                            cl.sendMessage(to, "沒有黑名單")
                elif text.lower().startswith("add "):
                    MENTION = eval(msg.contentMetadata['MENTION'])
                    inkey = MENTION['MENTIONEES'][0]['M']
                    if inkey not in ban["admin"]:
                        ban["admin"].append(str(inkey))
                        cl.sendMessage(to, "已獲得權限！")
                    else:
                        cl.sendMessage(to,"already")
                    json.dump(ban, codecs.open('ban.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False) 
                elif text.lower().startswith("del "):
                    MENTION = eval(msg.contentMetadata['MENTION'])
                    inkey = MENTION['MENTIONEES'][0]['M']
                    if inkey in ban["admin"]:
                        ban["admin"].remove(str(inkey))
                        cl.sendMessage(to, "已取消權限！")
                    else:
                    	cl.sendMessage(to,"user is not in admin")
                    json.dump(ban, codecs.open('ban.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False) 
                elif text.lower() == 'add':
                    wait["add"] = True
                    cl.sendMessage(to,"Please send a contact")
                elif text.lower() == 'del':
                    wait["del"] = True
                    cl.sendMessage(to,"Please send a Contact")
                elif text.lower().startswith("a "):
                    x = text.split(" ")
                    if not ismid(x[1]):
                        return
                    if x[1] not in ban["user"]:
                        ban["user"][x[1]] = []
                    if len(x) ==2:
                        t = 1
                    elif len(x) ==3:
                        try:
                            t = int(x[2])
                        except:
                            t = 0
                            cl.sendMessage(to,"it's not a number")
                    ban["user"][x[1]] += ["gid"]*t
                    cl.sendMessage(to,"ok")
                    json.dump(ban, codecs.open('ban.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False) 
                elif text.lower().startswith("ban "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    a = 0
                    for target in targets:
                        if target not in ban["owners"] and target not in ban["admin"] and target not in set["bots1"]:
                            ban["blacklist"][target] = True
                            a += 1
                    cl.sendMessage(msg.to,"已加入黑單共" + str(a) + "人")
                elif text.lower().startswith("clname:"):
                    name = text[7:]
                    c = cl.profile
                    c.displayName = name
                    cl.updateProfile(c)
                elif text.lower().startswith("botname:"):
                    name = text[8:]
                    for x in set["bot1"]:
                        c = x.profile
                        c.displayName = name
                        x.updateProfile(c)
                elif text.lower() == 'cclp':
                    wait["clp"] = True
                    cl.sendMessage(to,"send Pic")
                elif text.lower() == 'cbotp':
                    wait["botp"] = True
                    cl.sendMessage(to,"send Pic")
                elif text.lower().startswith("ban:"):
                    txt = text[4:].split(' ')
                    for mid in txt:
                        if not ismid(mid):
                            continue
                        if mid not in ban["owners"] and mid not in ban["admin"] and mid not in set["bots1"]:
                            ban["blacklist"][mid] = True
                            cl.sendMessage(msg.to,"已加入黑單!")
                elif text.lower().startswith("unban:"):
                    txt = text[6:].split(' ')
                    a = 0
                    for mid in txt:
                        try:
                            del ban["blacklist"][mid]
                            a+=1
                        except:
                            cl.sendMessage(msg.to,"刪除" + str(mid) + "失敗 !")
                    cl.sendMessage(msg.to,"已刪除黑單共" + str(a) + "人")
                elif text.lower().startswith("unban "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    a = 0
                    for target in targets:
                        try:
                            ban["blacklist"][target] =False
                            a += 1
                        except:
                            cl.sendMessage(msg.to,"刪除" + str(target) + "失敗 !")
                    cl.sendMessage(msg.to,"已刪除黑單共" + str(a) + "人")
                elif text.lower() == 'ban':
                    wait["ban"] = True
                    cl.sendMessage(to,"Please send a contact")
                elif text.lower() == 'unban':
                    wait["unban"] = True
                    cl.sendMessage(to,"Please send a Contact")
        if op.type == 25 or op.type ==26:
            msg = op.message
            if msg.contentType == 1:
                if msg._from in ban["owners"]:
                    if wait["clp"] == True:
                        path1 = cl.downloadObjectMsg(msg.id)
                        wait["clp"] = False
                        cl.updateProfilePicture(path1)
                        cl.sendMessage(msg.to, "Succes change pic")
                    elif wait["botp"] == True:
                        path1 = cl.downloadObjectMsg(msg.id)
                        wait["botp"] = False
                        for x in set["bot1"]:
                            x.updateProfilePicture(path1)
                        cl.sendMessage(msg.to, "Succes change pic")
            elif msg.contentType == 13:
                if wait["ban"] == True:
                    if msg._from in ban["owners"]:
                        if msg.contentMetadata["mid"] in ban["blacklist"]:
                           cl.sendmessage(msg.to,"already")
                           wait["ban"] = False
                        elif mid not in ban["owners"] and mid not in ban["admin"] and mid not in set["bots1"]:
                           ban["blacklist"][msg.contentMetadata["mid"]] = True
                           wait["ban"] = False
                           cl.sendMessage(msg.to,"成功新增黑單")
                elif wait["unban"] == True:
                    if msg._from in ban["owners"]:
                        if msg.contentMetadata["mid"] not in ban["blacklist"]:
                           cl.sendmessage(msg.to,"使用者並非黑單")
                           wait["unban"] = False
                        else:
                           del ban["blacklist"][msg.contentMetadata["mid"]]
                           wait["unban"] = False
                           cl.sendMessage(msg.to,"成功移除黑單")
                elif wait["add"] == True:
                    if msg._from in ban["owners"]:
                        if msg.contentMetadata["mid"] in ban["admin"]:
                           cl.sendmessage(msg.to,"already")
                           wait["add"] = False
                        elif msg.contentMetadata["mid"] not in ban["admin"]:
                           ban["admin"].append(str(msg.contentMetadata["mid"]))
                           wait["add"] = False
                           cl.sendMessage(msg.to,"成功新增權限")
                        else:
                           cl.sendMessage(msg.to,"使用者於黑單中無法新增權限")
                elif wait["del"] == True:
                    if msg._from in ban["owners"]:
                        if msg.contentMetadata["mid"] not in ban["admin"]:
                           cl.sendmessage(msg.to,"使用者不在權限中")
                           wait["del"] = False
                        else:
                           ban["admin"].remove(str(msg.contentMetadata["mid"]))
                           wait["del"] = False
                           cl.sendMessage(msg.to,"成功移除權限")
                if wait["mid"] ==True:
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    wait["mid"] =False
    except Exception as error:
        logError(error)
print("系統開始執行~")
while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
           #     lineBot(op)
                oepoll.setRevision(op.revision)
                thread = threading.Thread(target=lineBot, args=(op,))
                thread.start()
    except Exception as e:
        logError(e)
